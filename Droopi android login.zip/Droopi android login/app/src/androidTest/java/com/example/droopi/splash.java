package com.example.droopi;

public class splash {
}
